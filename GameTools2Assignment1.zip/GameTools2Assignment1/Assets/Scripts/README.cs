﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class README : MonoBehaviour {

    
    //  OLUWAMYOWA AKINOLA ANIMATION PROJECT
    // ANIMATIONS AND MODEL TAKEN OFF MIXAMO.COM
    // I MADE THIS PROJECT TO BE PLAYED USING A XBOX 360 CONTROLLER
   //  IF THIS IS NOT USE SOMETHINGS WOULD NOT WORK AS INTENDED OR FULL MECHANICS WOULD NOT BE UTILISED

      
   }

  
